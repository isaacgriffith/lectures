package cs2263.practicum02;

import java.util.*;

public class Product {

    enum Rating {
        A, B, C, D, E;

        static Map<String, Rating> map = new HashMap<>();
        static {
            map.put("A", A);
            map.put("B", B);
            map.put("C", C);
            map.put("D", D);
            map.put("E", E);
        }

        public static Rating forValue(String val) {
            if (map.containsKey(val))
                return map.get(val);
            else return null;
        }
    }

    private String modelName;
    private String manufacturerName;
    private double price;
    private Rating rating;
    private double overallReliability;
    private int numCustomers;

    public Product(String modelName, String manufacturerName, double price) {
        this.modelName = modelName;
        this.manufacturerName = manufacturerName;
        this.price = price;
    }

    public Product(String modelName, String manufacturerName) {
        this(modelName, manufacturerName, 0.0);
    }

    public double getOverallReliability() {
        return overallReliability;
    }

    public void setOverallReliability(double overallReliability) {
        this.overallReliability = overallReliability;
    }

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public String getManufacturerName() {
        return manufacturerName;
    }

    public void setManufacturerName(String manufacturerName) {
        this.manufacturerName = manufacturerName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Rating getRating() {
        return rating;
    }

    public void setRating(Rating rating) {
        this.rating = rating;
    }

    public int getNumCustomers() {
        return numCustomers;
    }

    public void setNumCustomers(int numCustomers) {
        this.numCustomers = numCustomers;
    }

    public void rateReliability(double reliability) {
        if (reliability < 0 || reliability > 5) {
            throw new IllegalArgumentException();
        }

        overallReliability = (overallReliability * numCustomers + reliability) / (++numCustomers);
    }

    public static void main(String[] args) {
        Product p = new Product("Test", "Test", 30.50);
        p.setNumCustomers(5);
        p.setRating(Rating.A);
        p.setOverallReliability(1.0);

        p.rateReliability(5.0);
        System.out.println("New Reliability: " + p.getOverallReliability());
    }
}
