package cs2263.practicum02;

import java.util.*;

/**
 * @author Isaac D Griffith
 * @version 1.0
 */
public class Product {

    /**
     * A simple Rating Enumeration
     */
    enum Rating {
        A, B, C, D, E;

        static Map<String, Rating> map = new HashMap<>();

        static {
            map.put("A", A);
            map.put("B", B);
            map.put("C", C);
            map.put("D", D);
            map.put("E", E);
        }

        /**
         * Method which returns the rating mapped to the provided value, or null if no such value exists
         *
         * @param val The value to find a rating for
         * @return The rating if one exists mapped to the provided value, or null if no such mapping exists
         */
        public static Rating forValue(String val) {
            if (map.containsKey(val))
                return map.get(val);
            else return null;
        }
    }

    private String modelName;
    private String manufacturerName;
    private double price;
    private Rating rating;
    private double overallReliability;
    private int numCustomers;

    /**
     * Construts a new product with the given model name, manufacturer name, and price.
     *
     * @param modelName        Model name
     * @param manufacturerName Mandufacturer name
     * @param price            Price
     */
    public Product(String modelName, String manufacturerName, double price) {
        this.modelName = modelName;
        this.manufacturerName = manufacturerName;
        this.price = price;
    }

    /**
     * Constructs a new Product with the given model name, manufacturer name, and a default price of 0.0
     *
     * @param modelName        Model name
     * @param manufacturerName Manufacturer name
     */
    public Product(String modelName, String manufacturerName) {
        this(modelName, manufacturerName, 0.0);
    }

    /**
     * Returns the overall reliability as rated
     *
     * @return the overall reliability
     */
    public double getOverallReliability() {
        return overallReliability;
    }

    /**
     * Sets the overall reliability rating
     *
     * @param overallReliability new overall reliability rating
     */
    public void setOverallReliability(double overallReliability) {
        this.overallReliability = overallReliability;
    }

    /**
     * Returns the model name
     *
     * @return the model name
     */
    public String getModelName() {
        return modelName;
    }

    /**
     * Sets the model name of this product
     *
     * @param modelName the model name
     */
    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    /**
     * Gets the manufacturer name of this product
     *
     * @return the manufacturer name
     */
    public String getManufacturerName() {
        return manufacturerName;
    }

    /**
     * Sets the manufacturer name of this product
     *
     * @param manufacturerName The new manufacturer name
     */
    public void setManufacturerName(String manufacturerName) {
        this.manufacturerName = manufacturerName;
    }

    /**
     * Gets the price of this product
     *
     * @return the price
     */
    public double getPrice() {
        return price;
    }

    /**
     * Sets the price of this product
     *
     * @param price the price
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * Gets the rating for this product
     *
     * @return the rating
     */
    public Rating getRating() {
        return rating;
    }

    /**
     * Sets the rating of this product
     *
     * @param rating the new rating
     */
    public void setRating(Rating rating) {
        this.rating = rating;
    }

    /**
     * Gets the number of customers who have rated this product
     *
     * @return the number of customers who rated
     */
    public int getNumCustomers() {
        return numCustomers;
    }

    /**
     * Sets the number of customers who have rated the product
     *
     * @param numCustomers the new number of customers
     */
    public void setNumCustomers(int numCustomers) {
        this.numCustomers = numCustomers;
    }

    /**
     * Provides a reliability rating for this product (must be a value between 0 and 5)
     *
     * @param reliability the reliability rating
     */
    public void rateReliability(double reliability) {
        if (reliability < 0 || reliability > 5) {
            throw new IllegalArgumentException();
        }

        overallReliability = (overallReliability * numCustomers + reliability) / (++numCustomers);
    }

    public static void main(String[] args) {
        Product p = new Product("Test", "Test", 30.50);
        p.setNumCustomers(5);
        p.setRating(Rating.A);
        p.setOverallReliability(1.0);

        p.rateReliability(5.0);
        System.out.println("New Reliability: " + p.getOverallReliability());
    }
}
