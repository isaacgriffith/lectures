package cs2263.practicum03.part01;

import java.util.Arrays;
import java.util.Scanner;

/**
 * @author Isaac D. Griffith
 * @version 1.0
 */
public class LongInteger {

    private int[] array;

    /**
     * Construct a new long integer with a value of 0
     */
    public LongInteger() {
        this(0);
    }

    /**
     * Create a new long integer from the provided number
     * @param number The number from which this long integer shall be created
     * @throws IllegalArgumentException if the provided number is less than 0
     */
    public LongInteger(int number) {
        // Check to ensure that the provide number is 0 or greater (we don't accept negative numbers)
        if (number < 0)
            throw new IllegalArgumentException("Cannot work with negative numbers");

        array = new int[50];

        // Set all the values to zero
        Arrays.fill(array, 0);

        // starting from the end of the array use modulus math to build up the array of digits
        int currentIndex = array.length - 1;
        while(number > 0) {
            int next = number % 10;
            number = number / 10;
            array[currentIndex] = next;
            currentIndex -= 1;
        }
    }

    /**
     * Reads in the values of the integer from standard in
     */
    public void readIn() {
        Scanner scanner = new Scanner(System.in);
        scanner.nextInt();
    }

    /**
     * Add the value of the provided number to the current represented integer, and returns a new LongInteger result
     * @param number value to be added
     * @return A new LongInteger representing the value of the addition
     */
    public LongInteger add(int number) {
        LongInteger li = new LongInteger(number);
        return this.add(li);
    }

    /**
     * Adds the value of the provided LongInteger to the current represented integer, and returns a new LongInteger result
     * @param number The representation of the value to be added
     * @return A new LongInteger representing the value of the addition
     */
    public LongInteger add(LongInteger number) {
        LongInteger hold = new LongInteger();

        for (int i = this.array.length - 1; i > 0; i--) {
            int value = number.array[i] + this.array[i];
            int rem = value % 10;
            int carry = value / 10;
            hold.array[i] += rem;
            if (i > 0)
                hold.array[i - 1] = carry;
        }

        return hold;
    }

    /**
     * @return A String representation of the integer
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();

        // Find the first non-zero index in the array
        int nonZeroIndex = -1;
        for (int i = 0; i < array.length; i++) {
            if (array[i] > 0) {
                nonZeroIndex = i;
                break;
            }
        }

        // if the nonzeroindex is still a -1 the value is zero, else start there and build the string.
        if (nonZeroIndex == -1)
            builder.append(0);
        else {
            for (int i = nonZeroIndex; i < array.length; i++) {
                builder.append(array[i]);
            }
        }
        return builder.toString();
    }

    public static void main(String[] args) {
        // Test 01 - Create a basic Long Integer with no parameters, should be zero
        System.out.print("Test 01 - ");
        LongInteger basicZero = new LongInteger();
        if (basicZero.toString().equals("0"))
            System.out.println("Pass");
        else
            System.out.println("Fail");

        // Test 02 - Create a LongInteger using a given number, the string representation should match
        System.out.print("Test 02 - ");
        LongInteger nonZero = new LongInteger(1001);
        if (nonZero.toString().equals("1001"))
            System.out.println("Pass");
        else
            System.out.println("Fail");

        // Test 03 - Create a LongInteger and add it to a given int, should match
        System.out.print("Test 03 - ");
        LongInteger firstAdd = new LongInteger(1000);
        LongInteger result = firstAdd.add(1234);
        if (result.toString().equals("2234"))
            System.out.println("Pass");
        else
            System.out.println("Fail");

        // Test 04 - Create a LongInteger and add it to zero, should have same value as before
        System.out.print("Test 04 - ");
        LongInteger secondAdd = new LongInteger(1000);
        result = secondAdd.add(0);
        if (result.toString().equals("1000"))
            System.out.println("Pass");
        else
            System.out.println("Fail");

        // Test 05 - Create two LongIntegers and add them, the value should match expected
        System.out.print("Test 05 - ");
        LongInteger thirdAdd = new LongInteger(1234);
        LongInteger fourthAdd = new LongInteger(1234);
        result = thirdAdd.add(fourthAdd);
        if (result.toString().equals(Integer.toString(1234 * 2)))
            System.out.println("Pass");
        else
            System.out.println("Fail");

        // Test 06 - Add Two LongIntegers where a carry would occur and the result should match expected
        System.out.print("Test 06 - ");
        LongInteger fifthAdd = new LongInteger(1111);
        LongInteger sixthAdd = new LongInteger(109999);
        result = fifthAdd.add(sixthAdd);
        if (result.toString().equals(Integer.toString(1111 + 109999)))
            System.out.println("Pass");
        else
            System.out.println("Fail");


        // Test 07 - Try to create a LongInteger with a negative value, should throw an exception
        System.out.print("Test 07 - ");
        try {
            LongInteger li = new LongInteger(-1);
            System.out.println("Fail");
        } catch (IllegalArgumentException e) {
            System.out.println("Pass");
        }
    }
}
