package cs2263.practicum03.part02;

/**
 * @author Isaac D. Griffith
 * @version 1.0
 */
public interface Extendable {
    /**
     * Appnds the character to the object that implements this interface
     *
     * @param c character to be appended
     * @return true if the append operation succeeded, false otherwise
     */
    boolean append(char c);

    /**
     * Appends all characters in the array to the object implementing this interface
     *
     * @param sequence array of characters to be appended
     * @return true if all the append operations succeed, false otherwise
     */
    boolean append(char[] sequence);
}
