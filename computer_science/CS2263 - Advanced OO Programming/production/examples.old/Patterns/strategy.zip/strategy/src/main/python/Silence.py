from QuackBehavior import QuackBehavior

class Silence(QuackBehavior):

    def quack(self):
        print "<< Silence >>"
