class FlyBehavior(object):

    def fly(self):
        pass
