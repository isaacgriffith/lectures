from FlyBehavior import FlyBehavior

class CantFly(FlyBehavior):

    def fly(self):
        print "I can't fly!"
