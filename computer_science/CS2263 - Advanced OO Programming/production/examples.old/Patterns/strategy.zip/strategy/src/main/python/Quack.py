from QuackBehavior import QuackBehavior

class Quack(QuackBehavior):

    def quack(self):
        print "Quack!"
