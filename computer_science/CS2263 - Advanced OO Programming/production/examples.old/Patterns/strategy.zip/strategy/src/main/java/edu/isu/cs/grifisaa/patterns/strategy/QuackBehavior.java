package edu.isu.cs.grifisaa.patterns.strategy;

public interface QuackBehavior {

	void quack();
}
