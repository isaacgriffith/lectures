class QuackBehavior(object):

    def quack(self):
        pass
