package edu.isu.cs.grifisaa.patterns.factory.AbstractFactory;

public class ThinCrustDough implements Dough {
	public String toString() {
		return "Thin Crust Dough";
	}
}
