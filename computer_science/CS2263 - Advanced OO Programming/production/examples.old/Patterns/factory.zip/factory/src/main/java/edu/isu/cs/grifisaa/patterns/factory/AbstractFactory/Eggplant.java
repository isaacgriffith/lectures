package edu.isu.cs.grifisaa.patterns.factory.AbstractFactory;

public class Eggplant implements Veggies {

	public String toString() {
		return "Eggplant";
	}
}
