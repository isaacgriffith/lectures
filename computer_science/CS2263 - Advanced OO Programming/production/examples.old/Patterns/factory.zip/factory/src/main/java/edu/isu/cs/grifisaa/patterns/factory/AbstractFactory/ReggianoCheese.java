package edu.isu.cs.grifisaa.patterns.factory.AbstractFactory;

public class ReggianoCheese implements Cheese {

	public String toString() {
		return "Reggiano Cheese";
	}
}
