package edu.isu.cs.grifisaa.patterns.factory.AbstractFactory;

public class Mushroom implements Veggies {

	public String toString() {
		return "Mushrooms";
	}
}
