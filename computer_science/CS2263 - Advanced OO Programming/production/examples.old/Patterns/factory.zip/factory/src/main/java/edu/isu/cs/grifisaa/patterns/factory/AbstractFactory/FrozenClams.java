package edu.isu.cs.grifisaa.patterns.factory.AbstractFactory;

public class FrozenClams implements Clams {

	public String toString() {
		return "Frozen Clams from Chesapeake Bay";
	}
}
