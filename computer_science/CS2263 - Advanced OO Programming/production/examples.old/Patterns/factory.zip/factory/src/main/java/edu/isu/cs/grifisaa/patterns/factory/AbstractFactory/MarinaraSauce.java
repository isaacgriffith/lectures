package edu.isu.cs.grifisaa.patterns.factory.AbstractFactory;

public class MarinaraSauce implements Sauce {
	public String toString() {
		return "Marinara Sauce";
	}
}
