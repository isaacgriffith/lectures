package edu.isu.cs.grifisaa.patterns.factory.AbstractFactory;

public class Spinach implements Veggies {

	public String toString() {
		return "Spinach";
	}
}
