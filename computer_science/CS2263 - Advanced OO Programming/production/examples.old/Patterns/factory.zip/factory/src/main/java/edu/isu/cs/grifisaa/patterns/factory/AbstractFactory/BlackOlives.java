package edu.isu.cs.grifisaa.patterns.factory.AbstractFactory;

public class BlackOlives implements Veggies {

	public String toString() {
		return "Black Olives";
	}
}
