package edu.isu.cs.grifisaa.patterns.factory.AbstractFactory;

public class ParmesanCheese implements Cheese {

	public String toString() {
		return "Shredded Parmesan";
	}
}
