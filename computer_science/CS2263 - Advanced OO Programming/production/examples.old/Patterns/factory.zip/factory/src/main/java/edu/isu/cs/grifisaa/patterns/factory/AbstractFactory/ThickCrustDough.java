package edu.isu.cs.grifisaa.patterns.factory.AbstractFactory;

public class ThickCrustDough implements Dough {
	public String toString() {
		return "ThickCrust style extra thick crust dough";
	}
}
