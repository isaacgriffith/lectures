package edu.isu.cs.grifisaa.patterns.factory.AbstractFactory;

public class RedPepper implements Veggies {

	public String toString() {
		return "Red Pepper";
	}
}
