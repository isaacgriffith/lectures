package edu.isu.cs.grifisaa.patterns.factory.AbstractFactory;

public interface Veggies {
	String toString();
}
