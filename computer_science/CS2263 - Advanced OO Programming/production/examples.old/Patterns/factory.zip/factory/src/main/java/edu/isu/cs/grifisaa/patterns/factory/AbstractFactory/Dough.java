package edu.isu.cs.grifisaa.patterns.factory.AbstractFactory;

public interface Dough {
	public String toString();
}
