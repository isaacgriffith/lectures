package edu.isu.cs.grifisaa.patterns.factory.AbstractFactory;

public interface Clams {
	public String toString();
}
