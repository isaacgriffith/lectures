package edu.isu.cs.grifisaa.patterns.factory.AbstractFactory;

public class SlicedPepperoni implements Pepperoni {

	public String toString() {
		return "Sliced Pepperoni";
	}
}
