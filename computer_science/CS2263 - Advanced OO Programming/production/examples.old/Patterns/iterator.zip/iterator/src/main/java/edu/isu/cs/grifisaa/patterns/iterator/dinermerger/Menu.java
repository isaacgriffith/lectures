package edu.isu.cs.grifisaa.patterns.iterator.dinermerger;

public interface Menu {
	Iterator createIterator();
}
