package edu.isu.cs.grifisaa.patterns.observable;

public interface DisplayElement {
	void display();
}
