package edu.isu.cs.grifisaa.patterns.observer;

public interface DisplayElement {
	void display();
}
