package edu.isu.cs.grifisaa.patterns.adapter;

public interface Duck {

  void quack();

  void fly();
}
