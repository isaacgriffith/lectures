package edu.isu.cs.grifisaa.patterns.adapter;

public interface Turkey {

  void gobble();

  void fly();
}
