package edu.isu.cs2263.lab03.prob02;

public class Square  {
    int value;
}
