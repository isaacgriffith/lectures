package graph2;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.*;

class PatternIndexTest {

    PrintStream oldOut;
    ByteArrayOutputStream stream;

    @BeforeEach
    void setup() {
        oldOut = System.out;
        stream = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(stream);
        System.setOut(ps);
    }

    @AfterEach
    void teardown() {
        System.out.flush();
        System.setOut(oldOut);
    }

    private void mainTest(String[] input, String expected) {
        PatternIndex.main(input);

        System.out.flush();
        String result = stream.toString();

        assertEquals(expected, result);
    }

    @Test
    void main() {
        String[] input = new String[0];
        mainTest(input, "java PatternIndex Subject Pattern\n");
    }

    @Test
    void main_2() {
        String[] input = {"foo", "bar"};
        mainTest(input, "Pattern string is not a substring of the subject string\n");
    }

    @Test
    void main_3() {
        String[] input = {"foobar", "oba"};
        mainTest(input, "Pattern string begins at character 2\n");
    }

    @Test
    void patternIndex() {
        int result = PatternIndex.patternIndex("", "a");
        assertEquals(-1, result);
    }

    @Test
    void patternIndex_2() {
        int result = PatternIndex.patternIndex("Too", "How");
        assertEquals(-1, result);
    }

    @Test
    void patternIndex_3() {
        int result = PatternIndex.patternIndex("Too", "Toa");
        assertEquals(-1, result);
    }

    @Test
    void patternIndex_4() {
        int result = PatternIndex.patternIndex("Foo", "Fo");
        assertEquals(0, result);
    }

    @Test
    void patternIndex_5() {
        assertThrows(NullPointerException.class, () -> PatternIndex.patternIndex(null, "a"));
    }

    @Test
    void patternIndex_6() {
        assertThrows(NullPointerException.class, () -> PatternIndex.patternIndex("subj", null));
    }
}