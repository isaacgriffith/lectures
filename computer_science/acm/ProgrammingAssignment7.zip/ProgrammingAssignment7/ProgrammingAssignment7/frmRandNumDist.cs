﻿// frmRandNumDists.cs
// CS 1181 
// Isaac Griffith
// 11/1/2018
// Me
// Description - Simple form to generate random numbers and display their frequencies
// WOW: none
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingAssignment7
{
    public partial class frmRandNumDist : Form
    {
        private int[] counts;
        private int[] array;

        /// <summary>
        /// Constructs a new form.
        /// </summary>
        public frmRandNumDist()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the generate button click event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGenerate_Click(object sender, EventArgs e)
        {
            Generate();
        }

        protected void Generate()
        {
            // Clear Lists
            Reset();
            tbSelect.Value = 1;

            // create the random number generator.
            Random rand = createRandom();
            
            // Create and populate the arrays
            int arraySize;
            int maxRand;
            if (ValidateArraySize(out arraySize))
            {
                array = new int[arraySize];
                
                if (ValidateMaxRand(out maxRand))
                {
                    counts = new int[maxRand + 1];
                    populateArrays(rand, arraySize, maxRand);
                    populateLists();                    

                    tbSelect.Maximum = arraySize;
                }
            }

        }

        /// <summary>
        /// Simple method to populate the listboxes based on the array contents
        /// </summary>
        protected void populateLists()
        {
            for (int i = 0; i < array.Length; i++)
            {
                lstArrayContents.Items.Add(array[i].ToString());
            }

            for (int i = 0; i < counts.Length; i++)
            {
                lstFrequency.Items.Add("There are " + counts[i].ToString() + " " + (i + 1) + "'s");
            }
        }

        /// <summary>
        /// Method which simply populates the value and counts arrays
        /// </summary>
        /// <param name="rand">The random number generator</param>
        /// <param name="arraySize">The array size</param>
        /// <param name="maxRand">The maximum number in the random range</param>
        protected void populateArrays(Random rand, int arraySize, int maxRand)
        {
            for (int i = 0; i < arraySize; i++)
            {
                int value = rand.Next(1, maxRand + 1);
                counts[value - 1] += 1;
                array[i] = value;
            }
        }

        /// <summary>
        /// Creates a new random number generator
        /// </summary>
        /// <returns>The newly created random number generator</returns>
        private Random createRandom()
        {
            int seed;
            Random rand;

            if (int.TryParse(txtSeed.Text, out seed))
            {
                rand = new Random(seed);
            }
            else
            {
                rand = new Random();
            }

            return rand;
        }

        /// <summary>
        /// Extracts and validates the array size value. If the value cannot be validated or extracted an appropriate warning is displayed.
        /// </summary>
        /// <param name="arraySize">Out parameter to which the array size should be stored</param>
        /// <returns>true if an only if the value can be parsed and validated, false otherwise.</returns>
        private bool ValidateArraySize(out int arraySize)
        {
            if (!int.TryParse(txtArraySize.Text, out arraySize))
            {
                MessageBox.Show("The number of random numbers to generate should be a number.");
                return false;
            }

            if (arraySize <= 0)
            {
                MessageBox.Show("The number of random numbers to generate should be greater than 0.");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Extracts and validates the maximum random number value. If the value is not valid, shows a warning message.
        /// </summary>
        /// <param name="maxRand">Out param to which the maximum random number value should be stored</param>
        /// <returns>True if the value can be extracted and is valid, false otherwise.</returns>
        private bool ValidateMaxRand(out int maxRand)
        {
            if (!int.TryParse(txtMaxVal.Text, out maxRand))
            {
                MessageBox.Show("The maximum value for random numbers generated should be a number.");
                return false;
            }

            if (maxRand < 1)
            {
                MessageBox.Show("The maximum value for random numbers generated should be greater than 1.");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Resets the form.
        /// </summary>
        private void Reset()
        {
            lstArrayContents.Items.Clear();
            lstFrequency.Items.Clear();
            lblValue.Text = "";
            lblValueAt.Text = "Value at Index :";
            tbSelect.Maximum = 1;
        }

        /// <summary>
        /// Handles the trackbar scroll event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbSelect_Scroll(object sender, EventArgs e)
        {
            UpdateTextValue();
        }

        /// <summary>
        /// Updates the Value At label and Value label when the Trackbar has been moved.
        /// </summary>
        private void UpdateTextValue()
        {
            lblValue.Text = array[tbSelect.Value - 1].ToString();
            lblValueAt.Text = "Value at Index " + (tbSelect.Value - 1) + ":";
        }

        /// <summary>
        /// Handle Form Load event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmRandNumDist_Load(object sender, EventArgs e)
        {
            Reset();
        }
    }
}
