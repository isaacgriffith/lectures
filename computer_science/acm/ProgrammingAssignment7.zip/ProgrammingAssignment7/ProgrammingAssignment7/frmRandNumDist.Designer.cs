﻿namespace ProgrammingAssignment7
{
    partial class frmRandNumDist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstArrayContents = new System.Windows.Forms.ListBox();
            this.txtSeed = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtArraySize = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMaxVal = new System.Windows.Forms.TextBox();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.tbSelect = new System.Windows.Forms.TrackBar();
            this.lstFrequency = new System.Windows.Forms.ListBox();
            this.lblValueAt = new System.Windows.Forms.Label();
            this.lblValue = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tbSelect)).BeginInit();
            this.SuspendLayout();
            // 
            // lstArrayContents
            // 
            this.lstArrayContents.FormattingEnabled = true;
            this.lstArrayContents.Location = new System.Drawing.Point(8, 11);
            this.lstArrayContents.Name = "lstArrayContents";
            this.lstArrayContents.ScrollAlwaysVisible = true;
            this.lstArrayContents.Size = new System.Drawing.Size(136, 784);
            this.lstArrayContents.TabIndex = 0;
            // 
            // txtSeed
            // 
            this.txtSeed.Location = new System.Drawing.Point(160, 31);
            this.txtSeed.Name = "txtSeed";
            this.txtSeed.Size = new System.Drawing.Size(255, 20);
            this.txtSeed.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(207, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Random Number Generator Seed";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(454, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(193, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Number of Random Values to Generate";
            // 
            // txtArraySize
            // 
            this.txtArraySize.Location = new System.Drawing.Point(421, 31);
            this.txtArraySize.Name = "txtArraySize";
            this.txtArraySize.Size = new System.Drawing.Size(255, 20);
            this.txtArraySize.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(288, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(171, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Generate numbers between 1 and ";
            // 
            // txtMaxVal
            // 
            this.txtMaxVal.Location = new System.Drawing.Point(460, 62);
            this.txtMaxVal.Name = "txtMaxVal";
            this.txtMaxVal.Size = new System.Drawing.Size(101, 20);
            this.txtMaxVal.TabIndex = 6;
            // 
            // btnGenerate
            // 
            this.btnGenerate.Location = new System.Drawing.Point(338, 101);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(148, 23);
            this.btnGenerate.TabIndex = 7;
            this.btnGenerate.Text = "Generate";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // tbSelect
            // 
            this.tbSelect.Location = new System.Drawing.Point(159, 128);
            this.tbSelect.Minimum = 1;
            this.tbSelect.Name = "tbSelect";
            this.tbSelect.Size = new System.Drawing.Size(516, 45);
            this.tbSelect.TabIndex = 8;
            this.tbSelect.Value = 1;
            this.tbSelect.Scroll += new System.EventHandler(this.tbSelect_Scroll);
            // 
            // lstFrequency
            // 
            this.lstFrequency.FormattingEnabled = true;
            this.lstFrequency.Location = new System.Drawing.Point(164, 230);
            this.lstFrequency.Name = "lstFrequency";
            this.lstFrequency.ScrollAlwaysVisible = true;
            this.lstFrequency.Size = new System.Drawing.Size(510, 563);
            this.lstFrequency.TabIndex = 9;
            // 
            // lblValueAt
            // 
            this.lblValueAt.AutoSize = true;
            this.lblValueAt.Location = new System.Drawing.Point(367, 172);
            this.lblValueAt.Name = "lblValueAt";
            this.lblValueAt.Size = new System.Drawing.Size(88, 13);
            this.lblValueAt.TabIndex = 10;
            this.lblValueAt.Text = "Value at Index #:";
            // 
            // lblValue
            // 
            this.lblValue.AutoSize = true;
            this.lblValue.Location = new System.Drawing.Point(397, 200);
            this.lblValue.Name = "lblValue";
            this.lblValue.Size = new System.Drawing.Size(21, 13);
            this.lblValue.TabIndex = 11;
            this.lblValue.Text = "##";
            // 
            // frmRandNumDist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 809);
            this.Controls.Add(this.lblValue);
            this.Controls.Add(this.lblValueAt);
            this.Controls.Add(this.lstFrequency);
            this.Controls.Add(this.tbSelect);
            this.Controls.Add(this.btnGenerate);
            this.Controls.Add(this.txtMaxVal);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtArraySize);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSeed);
            this.Controls.Add(this.lstArrayContents);
            this.Name = "frmRandNumDist";
            this.Text = "Random Number Distribution";
            this.Load += new System.EventHandler(this.frmRandNumDist_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tbSelect)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstArrayContents;
        private System.Windows.Forms.TextBox txtSeed;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtArraySize;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMaxVal;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.TrackBar tbSelect;
        private System.Windows.Forms.ListBox lstFrequency;
        private System.Windows.Forms.Label lblValueAt;
        private System.Windows.Forms.Label lblValue;
    }
}

