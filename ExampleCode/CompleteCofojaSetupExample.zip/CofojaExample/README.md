## Cofoja (Setup) Example ##

This is a **complete** example how to configure the Design by Contract library [Cofoja](https://github.com/nhatminhle/cofoja) in Maven, Gradle, Eclipse and IntelliJ IDEA.

For more information and screen shots see my blog [Complete Cofoja Setup Example](http://blog.code-cop.org/2018/02/complete-cofoja-setup-example.html).

### License ###
This work is licensed under a [New BSD License](http://opensource.org/licenses/bsd-license.php), see `license.txt` in repository.
